package main

import (
	"fmt"
	"strconv"
	"strings"
)

type Poker struct {
	face  string
	color string
	card  string //排序后牌大小
}
func main(){
	facesSort:="abcd"
	strings.Index(facesSort, "c")
 var s int32=6
 fmt.Println(strconv.Itoa(int(s)))


}